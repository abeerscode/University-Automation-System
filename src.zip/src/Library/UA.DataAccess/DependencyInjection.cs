using Microsoft.Extensions.DependencyInjection;
using UA.DataAccess.Data;

namespace UA.DataAccess;

public static class DependencyInjection
{
    public static IServiceCollection AddUniversityDataAccess(this IServiceCollection services, string connectionString)
    {
        services.AddDbContext<UniversityDbContext>(options => options.UseSqlServer(connectionString));
        return services;
    }
}
