using Microsoft.Extensions.DependencyInjection;
using UA.DataAccess;

namespace UA.Facade;

public static class DependencyInjection
{
    public static IServiceCollection AddUniversityBusiness(this IServiceCollection services, string connectionString)
    {
        services.AddUniversityDataAccess(connectionString);
        return services;
    }
}
