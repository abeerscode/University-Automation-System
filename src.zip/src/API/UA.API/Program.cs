using UA.Facade;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddOpenApi();

var universityConnectionString = Environment.GetEnvironmentVariable("UNIVERSITY_DB")
    ?? builder.Configuration.GetConnectionString("DefaultConnection");
if (string.IsNullOrWhiteSpace(universityConnectionString))
{
    throw new InvalidOperationException(
        "Database connection string is missing. Set UNIVERSITY_DB or ConnectionStrings:DefaultConnection.");
}
builder.Services.AddUniversityBusiness(universityConnectionString);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
}

app.UseHttpsRedirection();

app.Run();
